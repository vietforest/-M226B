package ch.samt.talentshow.enumerator;

public enum Category {
    DANCER,
    SINGER,
    MAGICIAN,
}
