package ch.samt.talentshow.enumerator;

public enum Level {
    BEGINNER,
    INTERMEDIATE,
    PROFESSIONAL,
}
