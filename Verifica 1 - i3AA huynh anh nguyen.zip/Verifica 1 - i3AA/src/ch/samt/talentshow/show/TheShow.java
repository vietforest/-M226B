package ch.samt.talentshow.show;

public interface TheShow {
    void show();//polymorphism
    void point();//heritage
}
